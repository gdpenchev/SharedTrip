﻿using MyWebServer.Controllers;
using MyWebServer.Http;
using SharedTrip.Data;
using SharedTrip.Forms.Trip;
using SharedTrip.Models;
using SharedTrip.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedTrip.Controllers
{
    public class TripsController : Controller
    {
        private readonly ApplicationDbContext data;
        private readonly IValidator validator;

        public TripsController(ApplicationDbContext data, IValidator validator)
        {
            this.data = data;
            this.validator = validator;
        }
        [Authorize]
        public HttpResponse Add() => View();
        [Authorize]
        [HttpPost]
        public HttpResponse Add(AddTripFormModel model)
        {
            var modelErrors = this.validator.ValidateTrip(model);

            if (modelErrors.Any())
            {
                return Error(modelErrors);
            }

            var trip = new Trip
            {
                StartPoint = model.StartPoint,
                EndPoint = model.EndPoint,
                DepartureTime = model.DepartureTime,
                Seats = model.Seats,
                ImagePath = model.ImagePath,
                Description = model.Description
            };
            this.data.Trips.Add(trip);

            this.data.SaveChanges();

            return Redirect("/Trips/All");
        }
        [Authorize]
        public HttpResponse All()
        {
            var allTrips = this.data.Trips
                .Select(t => new TripAllListingViewFormModel
                {
                    TripId = t.Id,
                    StartPoint = t.StartPoint,
                    EndPoint = t.EndPoint,
                    DepartureTime = t.DepartureTime,
                    Seats = t.Seats
                }).ToList();

            return View(allTrips);
        }
        [Authorize]
        public HttpResponse Details(string tripId)
        {
            if (tripId == null)
            {
                return BadRequest();
            }
            var currentTrip = this.data.Trips.Where(t => t.Id == tripId)
                .Select(t => new DetailsTripFormModel
                {
                    TripId = t.Id,
                    StartPoint = t.StartPoint,
                    EndPoint = t.EndPoint,
                    DepartureTime = t.DepartureTime,
                    Seats = t.Seats,
                    Description = t.Description
                }).FirstOrDefault();

            return View(currentTrip);
        }
        [Authorize]
        public HttpResponse AddUserToTrip(string tripId)
        {
            var currentTrip = this.data.Trips.Where(t => t.Id == tripId).FirstOrDefault();

            var currentUser = this.data.Users.Where(u => u.Id == this.User.Id).FirstOrDefault();


            var userTrip = new UserTrip
            {
                UserId = currentUser.Id,
                TripId = currentTrip.Id
            };
            
            this.data.UserTrips.Add(userTrip);

            this.data.SaveChanges();

            return Redirect("/Trips/All");
        }


    }
}
